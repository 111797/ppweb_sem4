<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="upload_proc.php" method="post" enctype="multipart/form-data">
		Pilih File 
		<input type="file" name="dokumen">
		<input type="submit" name="upload" value="UPLOAD">
	</form>
</body>
</html>