<a href="./mhs.php">Lihat</a>
<a href="./mhs_add.php">Tambah</a>