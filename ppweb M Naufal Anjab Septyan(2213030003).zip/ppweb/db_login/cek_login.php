<?php
    session_start();
	echo 'username: '.$_SESSION['username'];
	echo '<br>Nama: '.$_SESSION['nama'];
?>