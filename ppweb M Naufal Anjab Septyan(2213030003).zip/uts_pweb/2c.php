<?php

$a=9;
if($a<5){
  echo " Satu satu";
  $a++;
}
if($a<10){
  echo " Aku Sayang Ibu";
  $a+=10;
}
if($a<20){
  echo " Dua dua";
  $a+=10;
}
if($a<15){
  echo " Aku Sayang Ayah";
  $a+=10;
}
?>