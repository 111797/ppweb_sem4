<?php

for ($i = 1; $i <= 7; $i++) {
  // Print numbers in each row
  for ($j = 1; $j <= $i; $j++) {
    echo $i.' ';
  }
  // Move to a new line after each row
  echo "<br>";
}

?>
