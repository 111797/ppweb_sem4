<?php
for($i=10; $i<10; $i--){  // Loop will never run
  echo $i."";
}
?>
